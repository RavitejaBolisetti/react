import { combineReducers } from 'redux';
import { LoginPage } from './LoginPage';

export const authPages = combineReducers({
    LoginPage,
});
