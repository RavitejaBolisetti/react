export const showLoadingCF = (state, action) => ({
    ...state,
    isLoading: action.isLoading,
});
