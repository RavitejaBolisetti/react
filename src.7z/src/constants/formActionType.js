export const FROM_ACTION_TYPE = { ADD: 'add', EDIT: 'edit', VIEW: 'view', CHILD: 'child', SIBLING: 'sibling' };
