export const ENCRYPT_KEY = process.env.REACT_APP_ENCRYPT_SECRET_KEY;
export const HIERARCHY_DEFAULT_PARENT = 'DMS';
export const DEFAULT_PAGE_SIZE = 10;
