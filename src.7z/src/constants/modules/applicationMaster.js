export const ACCESSIBLE_LOCATION_INDICATOR = {
    0: 'Accessible to all',
    1: 'Not accessible to all',
    2: 'Restricted Accessible',
};