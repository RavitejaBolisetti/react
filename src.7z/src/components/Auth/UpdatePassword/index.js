import { UpdatePassword } from './UpdatePassword';

export { UpdatePassword };
