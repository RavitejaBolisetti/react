import { ForgotPassword } from './ForgotPassword';

export { ForgotPassword };
