import { Login } from './Login';
import { ForgotPassword } from './ForgotPassword';
import { UpdatePassword } from './UpdatePassword';

export { Login, ForgotPassword, UpdatePassword };
