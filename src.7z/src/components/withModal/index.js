import { withModal } from './withModal';

export { withModal };
