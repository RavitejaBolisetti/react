import { Splash } from './Splash'

export { Splash }
