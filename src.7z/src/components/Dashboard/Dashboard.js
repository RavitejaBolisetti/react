import React, { useState } from 'react';
import { connect } from 'react-redux';
import imdimg from 'assets/img/img_md.png';
import { Carousel, Card, Button, Row, Col, Input } from 'antd';
import { AiFillDashboard } from 'react-icons/ai';
import { BsFillBarChartFill, BsCalendarEvent } from 'react-icons/bs';
import { BiLineChart } from 'react-icons/bi';
import { TbSpeakerphone } from 'react-icons/tb';
import { FaChartPie, FaChartArea, FaClock, FaNewspaper, FaChalkboard, FaBookOpen } from 'react-icons/fa';
import { convertDateTime } from 'utils/formatDateTime';
import styles from './Dashboard.module.css';
import moment from 'moment';

const { Search } = Input;

const mapStateToProps = (state) => {
    const {
        common: {
            LeftSideBar: { collapsed = false },
            Header: { data: loginUserData = [] },
        },
    } = state;

    return {
        collapsed,
        firstName: loginUserData?.firstName || '',
    };
};

const DashboardBase = ({ props }) => {
    const onSearch = (value) => console.log(value);
    const firstName = '';

    return (
        <div className={styles.dashboardContainer}>
            <Row gutter={20}>
                <Col xs={24} sm={24} md={12} lg={24} xl={24} xxl={24}>
                    <Row gutter={20}>
                        <Col xs={24} sm={24} md={12} lg={18} xl={18} xxl={18}>
                            <div className={styles.dashboardPageHeading}>
                                {/* <span className={styles.headingGradient}>Welcome back {firstName}! </span> */}
                                <span className={styles.headingGradient}>Home</span>
                            </div>
                        </Col>
                        {/* <Col xs={24} sm={24} md={12} lg={6} xl={6} xxl={6} className={styles.floatRight}>
                            <Search allowClear placeholder="Enter Doc ID..." onSearch={onSearch} />
                        </Col> */}
                    </Row>
                    <div className={styles.pageHeaderNameSection}></div>
                </Col>
            </Row>
            <Row gutter={20}>
                <Col xs={24} sm={24} md={12} lg={8} xl={8} xxl={8}>
                    <Card
                        title={
                            <>
                                <AiFillDashboard size={21} className={styles.svgIcon} /> Dashboard
                            </>
                        }
                        className={styles.dashboardCard}
                    >
                        <div className={styles.dashboardGraph}>
                            <div className={styles.dashboardGraphBox}>
                                <div className={styles.graphBoxfirstSec}>
                                    <BsFillBarChartFill />
                                </div>
                                <div className={styles.graphBoxSecoundSec}>
                                    <FaChartPie />
                                </div>
                                <div className={styles.graphBoxthirdSec}>
                                    <BiLineChart />
                                </div>
                                <div className={styles.graphBoxforthSec}>
                                    <FaChartArea />
                                </div>
                            </div>

                            <div className={styles.buttonHolder}>
                                <Button className=" mrl15" danger type="primary">
                                    View Dashboard
                                </Button>
                            </div>
                        </div>
                    </Card>
                </Col>
                <Col xs={24} sm={24} md={12} lg={8} xl={8} xxl={8}>
                    <Card
                        title={
                            <>
                                <FaClock size={21} className={styles.svgIcon} /> Action Items
                            </>
                        }
                        className={styles.dashboardCard}
                    >
                        <div className={styles.directChatMessages}>
                            <div className={styles.scrollbar}>
                                <div className="force-overflow">
                                    <ul className={styles.dashboardList}>
                                        <li>
                                            Enquiries to be followed up <span className={`${styles.badge} ${styles.badgedanger}`}>6</span>
                                        </li>
                                        <li>
                                            Pending POs to be released <span className={`${styles.badge} ${styles.badgedanger}`}>12</span>
                                        </li>
                                        <li>
                                            Vehicles to be delivered <span className={`${styles.badge} ${styles.badgedanger}`}>10</span>
                                        </li>
                                        <li>
                                            Enquiries to be followed up <span className={`${styles.badge} ${styles.badgedanger}`}>6</span>
                                        </li>
                                        <li>
                                            Enquiries to be followed up <span className={`${styles.badge} ${styles.badgedanger}`}>6</span>
                                        </li>
                                        <li>
                                            Enquiries to be followed up <span className={`${styles.badge} ${styles.badgedanger}`}>6</span>
                                        </li>
                                        <li>
                                            Enquiries to be followed up <span className={`${styles.badge} ${styles.badgedanger}`}>6</span>
                                        </li>
                                        <li>
                                            Enquiries to be followed up <span className={`${styles.badge} ${styles.badgedanger}`}>6</span>
                                        </li>
                                        <li>
                                            Enquiries to be followed up <span className={`${styles.badge} ${styles.badgedanger}`}>6</span>
                                        </li>
                                        <li>
                                            Enquiries to be followed up <span className={`${styles.badge} ${styles.badgedanger}`}>6</span>
                                        </li>
                                        <li>
                                            Enquiries to be followed up <span className={`${styles.badge} ${styles.badgedanger}`}>6</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </Card>
                </Col>
                <Col xs={24} sm={24} md={12} lg={8} xl={8} xxl={8}>
                    <Card
                        title={
                            <>
                                <TbSpeakerphone size={21} className={styles.svgIcon} /> News
                            </>
                        }
                        className={styles.dashboardCard}
                    >
                        <div className={styles.dashboardGraph}>
                            <div className={styles.dashboardGraphBox}>
                                <div className={styles.newsCard}>
                                    <h4>New Mahindra showroom</h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur....</p>
                                </div>
                            </div>
                            <div className={styles.buttonHolder}>
                                <Button className=" mrl15" danger type="primary">
                                    View More
                                </Button>
                            </div>
                        </div>
                        {/* <Carousel autoplay>
                            <div className={styles.newsCarsulalContaner}>
                                <div className={styles.dashboardboxContHeight}>
                                    <h4>Anand Mahindra Highlights Car Price Hikes Over 50 Years Ago</h4>
                                    <div className="textContaner">Anand Mahindra continues to amuse the netizens with his posts. This time he has highlighted car price hikes from 50 years ago. </div>
                                </div>
                                <div className={styles.buttonHolder}>
                                    <Button className=" mrl15" danger type="primary">
                                        View Dashboard
                                    </Button>
                                </div>
                            </div>

                            <div className={styles.newsCarsulalContaner}>
                                <div className={styles.dashboardboxContHeight}>
                                    <h4>What to expect from Mahindra's Born Electric concept SUVs</h4>
                                    <div className="textContaner">Homegrown SUV specialist Mahindra revealed five concept electric SUVs at the brand's European design studio in August last year. </div>
                                </div>
                                <div className={styles.buttonHolder}>
                                    <Button className="mrl15" danger type="primary">
                                        View Dashboard
                                    </Button>
                                </div>
                            </div>

                            <div className={styles.newsCarsulalContaner}>
                                <div className={styles.dashboardboxContHeight}>
                                    <h4>Mahindra SUV sales up 66% </h4>
                                    <div className="textContaner">Mahindra SUV sales up 66% in Jan 2023: Scorpio-N, Thar, XUV700 drive growthMahindra & Mahindra Ltd today announced that its overall auto sales for the month of January 2023 stood at 64,335 vehicles.</div>
                                </div>
                                <div className={styles.buttonHolder}>
                                    <Button className=" mrl15" danger type="primary">
                                        View Dashboard
                                    </Button>
                                </div>
                            </div>
                        </Carousel> */}
                    </Card>
                </Col>
                <Col xs={24} sm={24} md={12} lg={8} xl={8} xxl={8}>
                    <Card
                        title={
                            <>
                                <FaChalkboard size={21} className={styles.svgIcon} /> Upcoming Trainings
                            </>
                        }
                        className={styles.dashboardCard}
                    >
                        <div className={styles.dashboardGraph}>
                            <div className={styles.dashboardGraphBox}>
                                <div className={styles.trainingCard}>
                                    <h4>Mahindra powertrain</h4>
                                    <p>Greeting and welcoming the customer</p>
                                </div>
                                <div className={styles.trainingCard}>
                                    <h4>Mahindra powertrain</h4>
                                    <p>Greeting and welcoming the customer</p>
                                </div>
                            </div>
                            <div className={styles.buttonHolder}>
                                <Button className=" mrl15" danger type="primary">
                                    View More
                                </Button>
                            </div>
                        </div>
                    </Card>
                </Col>
                <Col xs={24} sm={24} md={12} lg={8} xl={8} xxl={8}>
                    <Card
                        title={
                            <>
                                <BsCalendarEvent size={21} className={styles.svgIcon} /> Birthday Calendar
                            </>
                        }
                        className={styles.dashboardCard}
                    >
                        <div className={styles.birthContainer}>
                            <div className={styles.birthdayItem}>
                                <div className={styles.birthdayImgcontaner}>
                                    <img src={imdimg} alt="" />
                                </div>
                                <div className={styles.birthdayTxtcontaner}>
                                    <div className={styles.birthdayName}>First Name, Last Name</div>
                                    <div>Today - {convertDateTime(moment(), 'D MMM ')}.</div>
                                </div>
                            </div>
                            <div className={styles.separator}></div>
                            <div className={styles.birthdayItem}>
                                <div className={styles.birthdayImgcontaner}>
                                    <img src={imdimg} alt="" />
                                </div>
                                <div className={styles.birthdayTxtcontaner}>
                                    <div className={styles.birthdayName}>First Name, Last Name</div>
                                    <div>Today - {convertDateTime(moment(), 'D MMM ')}.</div>
                                </div>
                            </div>
                            <div className={styles.separator}></div>
                            <div className={styles.birthdayItem}>
                                <div className={styles.birthdayImgcontaner}>
                                    <img src={imdimg} alt="" />
                                </div>
                                <div className={styles.birthdayTxtcontaner}>
                                    <div className={styles.birthdayName}>First Name, Last Name</div>
                                    <div>Today - {convertDateTime(moment(), 'D MMM ')}.</div>
                                </div>
                            </div>
                        </div>
                        {/* <Carousel autoplay>
                            <div className={styles.birthContainer}>
                                <div className={styles.birthdayItem}>
                                    <div className={styles.birthdayImgcontaner}>
                                        <img src={imdimg} alt="" />
                                    </div>
                                    <div className={styles.birthdayTxtcontaner}>
                                        <div className={styles.birthdayName}>First Name, Last Name</div>
                                        <div>Today - {convertDateTime(moment(), 'D MMM ')}.</div>
                                    </div>
                                </div>
                                <div className={styles.separator}></div>
                                <div className={styles.birthdayItem}>
                                    <div className={styles.birthdayImgcontaner}>
                                        <img src={imdimg} alt="" />
                                    </div>
                                    <div className={styles.birthdayTxtcontaner}>
                                        <div className={styles.birthdayName}>First Name, Last Name</div>
                                        <div>Today - {convertDateTime(moment(), 'D MMM ')}.</div>
                                    </div>
                                </div>
                                <div className={styles.separator}></div>
                                <div className={styles.birthdayItem}>
                                    <div className={styles.birthdayImgcontaner}>
                                        <img src={imdimg} alt="" />
                                    </div>
                                    <div className={styles.birthdayTxtcontaner}>
                                        <div className={styles.birthdayName}>First Name, Last Name</div>
                                        <div>Today - {convertDateTime(moment(), 'D MMM ')}.</div>
                                    </div>
                                </div>
                            </div>
                            <div className={styles.birthContainer}>
                                <div className={styles.birthdayItem}>
                                    <div className={styles.birthdayImgcontaner}>
                                        <img src={imdimg} alt="" />
                                    </div>
                                    <div className={styles.birthdayTxtcontaner}>
                                        <div className={styles.birthdayName}>First Name, Last Name</div>
                                        <div>Today - {convertDateTime(moment(), 'D MMM ')}.</div>
                                    </div>
                                </div>
                                <div className={styles.separator}></div>
                                <div className={styles.birthdayItem}>
                                    <div className={styles.birthdayImgcontaner}>
                                        <img src={imdimg} alt="" />
                                    </div>
                                    <div className={styles.birthdayTxtcontaner}>
                                        <div className={styles.birthdayName}>First Name, Last Name</div>
                                        <div>Today - {convertDateTime(moment(), 'D MMM ')}.</div>
                                    </div>
                                </div>
                                <div className={styles.separator}></div>
                                <div className={styles.birthdayItem}>
                                    <div className={styles.birthdayImgcontaner}>
                                        <img src={imdimg} alt="" />
                                    </div>
                                    <div className={styles.birthdayTxtcontaner}>
                                        <div className={styles.birthdayName}>First Name, Last Name</div>
                                        <div>Today - {convertDateTime(moment(), 'D MMM ')}.</div>
                                    </div>
                                </div>
                            </div>
                            <div className={styles.birthContainer}>
                                <div className={styles.birthdayItem}>
                                    <div className={styles.birthdayImgcontaner}>
                                        <img src={imdimg} alt="" />
                                    </div>
                                    <div className={styles.birthdayTxtcontaner}>
                                        <div className={styles.birthdayName}>First Name, Last Name</div>
                                        <div>Today - {convertDateTime(moment(), 'D MMM ')}.</div>
                                    </div>
                                </div>
                                <div className={styles.separator}></div>
                                <div className={styles.birthdayItem}>
                                    <div className={styles.birthdayImgcontaner}>
                                        <img src={imdimg} alt="" />
                                    </div>
                                    <div className={styles.birthdayTxtcontaner}>
                                        <div className={styles.birthdayName}>First Name, Last Name</div>
                                        <div>Today - {convertDateTime(moment(), 'D MMM ')}.</div>
                                    </div>
                                </div>
                                <div className={styles.separator}></div>
                                <div className={styles.birthdayItem}>
                                    <div className={styles.birthdayImgcontaner}>
                                        <img src={imdimg} alt="" />
                                    </div>
                                    <div className={styles.birthdayTxtcontaner}>
                                        <div className={styles.birthdayName}>First Name, Last Name</div>
                                        <div>Today - {convertDateTime(moment(), 'D MMM ')}.</div>
                                    </div>
                                </div>
                            </div>
                        </Carousel> */}
                    </Card>
                </Col>
                <Col xs={24} sm={24} md={12} lg={8} xl={8} xxl={8}>
                    <Card
                        title={
                            <>
                                <FaBookOpen size={21} className={styles.svgIcon} /> Knowledge Center
                            </>
                        }
                        className={styles.dashboardCard}
                    >
                        <div className={styles.dashboardGraph}>
                            <div className={styles.dashboardGraphBox}>
                                <div className={styles.trainingCard}>
                                    <h4>Lorem Ipsum</h4>
                                    <p>It is sometimes known as dummy text</p>
                                </div>
                                <div className={styles.trainingCard}>
                                    <h4>Lorem Ipsum</h4>
                                    <p>It is sometimes known as dummy text</p>
                                </div>
                            </div>
                            <div className={styles.buttonHolder}>
                                <Button className=" mrl15" danger type="primary">
                                    View More
                                </Button>
                            </div>
                        </div>
                    </Card>
                </Col>
            </Row>
        </div>
    );
};

export const Dashboard = connect(mapStateToProps, null)(DashboardBase);
