import { DealerParent } from "./DealerParent";

export { DealerParent };