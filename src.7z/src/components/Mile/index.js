import { DealerParent } from './DealerParent';
import {DealerCompany} from './DealerCompany';

export{DealerCompany, DealerParent};