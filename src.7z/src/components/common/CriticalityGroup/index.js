import { CriticalityGroup } from './CriticalityGroup';

export { CriticalityGroup };
