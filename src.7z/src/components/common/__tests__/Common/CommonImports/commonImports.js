export const fetchList = () => {
    return;
};
export const saveData = () => {
    return;
};
export const hierarchyAttributeFetchList = () => {
    return;
};
export const listShowLoading = () => {
    return;
};
export const fetchMenuList = () => {
    return;
};
export const fetchRole = () => {
    return;
};
