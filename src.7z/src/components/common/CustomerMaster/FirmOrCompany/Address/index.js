import {CompanyAddressMaster} from './CompanyAddressMaster';

export {CompanyAddressMaster};