import { CompanyContact } from './CompanyContactMaster';
export { CompanyContact }