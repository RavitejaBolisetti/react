import { CompanyProfile } from "./CompanyProfile";
export { CompanyProfile };