import {IndividualAddressMaster} from './IndividualAddressMaster';

export {IndividualAddressMaster};