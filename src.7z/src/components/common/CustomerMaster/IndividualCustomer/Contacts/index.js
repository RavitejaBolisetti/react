import { IndividualContact } from './IndividualContactMaster';
export { IndividualContact }