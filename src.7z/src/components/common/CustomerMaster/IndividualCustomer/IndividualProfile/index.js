import { IndividualProfileMaster } from './IndividualProfileMaster';

export { IndividualProfileMaster };
