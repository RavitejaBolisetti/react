import { IndividualAccountRelatedMaster } from './IndividualAccountRelatedMaster';
export { IndividualAccountRelatedMaster };
