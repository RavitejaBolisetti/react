import IndivisualCustomerDetailsMaster from './IndivisualCustomerDetailsMaster';
export { IndivisualCustomerDetailsMaster };
