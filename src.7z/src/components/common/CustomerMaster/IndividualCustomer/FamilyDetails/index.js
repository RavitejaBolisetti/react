import { FamilyDetails } from './FamilyDetailsMaster';

export { FamilyDetails }