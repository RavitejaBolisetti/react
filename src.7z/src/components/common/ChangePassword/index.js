import { ChangePassword } from './ChangePassword';

export { ChangePassword };
