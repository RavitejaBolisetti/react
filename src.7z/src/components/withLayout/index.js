import { withLayout } from './withLayout';

export { withLayout };
