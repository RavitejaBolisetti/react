import { LANGUAGE_EN } from 'en';
export { LANGUAGE_EN };
